// Initial Property Data (Stored and synced with localStorage)
const defaultProperties = [
    {
        id: 1,
        title: "Sona Dream Residential Plot",
        type: "Plot",
        location: "Wajegaon, Nanded",
        price: 1200000,
        size: "1,200 sq.ft",
        image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=800&q=80",
        description: "NA approved residential plotting development with wide approach roads, electricity, and water supply."
    },
    {
        id: 2,
        title: "Luxurious 3BHK Duplex House",
        type: "House",
        location: "CIDCO, Nanded",
        price: 6500000,
        size: "2,100 sq.ft",
        image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=800&q=80",
        description: "Modern independent duplex with premium marble flooring, modular kitchen, parking, and balcony view."
    },
    {
        id: 3,
        title: "Commercial Retail Shop",
        type: "Commercial",
        location: "Itwara, Nanded",
        price: 3500000,
        size: "450 sq.ft",
        image: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80",
        description: "High footfall commercial shop space ideal for showrooms, offices, or retail outlets."
    },
    {
        id: 4,
        title: "Prime Agricultural Farmland",
        type: "Agricultural",
        location: "Near Nanded",
        price: 2800000,
        size: "2 Acres",
        image: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&w=800&q=80",
        description: "Fertile agricultural land with abundant groundwater source and direct road connectivity."
    }
];

// Initialize LocalStorage Data
if (!localStorage.getItem('up_properties')) {
    localStorage.setItem('up_properties', JSON.stringify(defaultProperties));
}
if (!localStorage.getItem('up_leads')) {
    localStorage.setItem('up_leads', JSON.stringify([
        { id: 1, name: "Sandeep Patil", phone: "9823000000", interest: "Plot", msg: "Looking for a plot in Wajegaon." }
    ]));
}

// Mobile Menu Toggle
const menuBtn = document.getElementById('menuBtn');
const mobileMenu = document.getElementById('mobileMenu');
if(menuBtn && mobileMenu) {
    menuBtn.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
    });
}

// Render Properties on Homepage
function renderProperties(propertiesToRender) {
    const grid = document.getElementById('propertyGrid');
    if(!grid) return;
    
    if (propertiesToRender.length === 0) {
        grid.innerHTML = `<div class="col-span-3 text-center py-12 text-slate-500 font-medium">No properties found matching your criteria.</div>`;
        return;
    }

    grid.innerHTML = propertiesToRender.map(prop => `
        <div class="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition duration-300 border border-slate-100 flex flex-col justify-between">
            <div>
                <div class="relative h-56 overflow-hidden">
                    <img src="${prop.image}" alt="${prop.title}" class="w-full h-full object-cover hover:scale-105 transition duration-500">
                    <span class="absolute top-4 left-4 bg-amber-500 text-slate-900 font-bold text-xs px-3 py-1.5 rounded-full uppercase tracking-wider shadow">
                        ${prop.type}
                    </span>
                </div>
                <div class="p-6">
                    <div class="flex items-center gap-2 text-slate-500 text-xs font-semibold mb-2">
                        <i class="fa-solid fa-location-dot text-amber-500"></i> ${prop.location}
                    </div>
                    <h3 class="font-black text-xl text-slate-900 mb-2 line-clamp-1">${prop.title}</h3>
                    <p class="text-slate-600 text-sm mb-4 line-clamp-2">${prop.description}</p>
                    <div class="flex items-center justify-between font-bold text-slate-900 pt-3 border-t border-slate-100">
                        <span class="text-amber-600 text-lg">₹ ${Number(prop.price).toLocaleString('en-IN')}</span>
                        <span class="text-xs bg-slate-100 text-slate-600 px-3 py-1.5 rounded-lg"><i class="fa-solid fa-ruler-combined mr-1"></i> ${prop.size}</span>
                    </div>
                </div>
            </div>
            <div class="p-6 pt-0 flex gap-3">
                <button onclick="openPropertyModal(${prop.id})" class="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl text-sm transition shadow-sm">
                    View Details
                </button>
                <a href="https://wa.me/919881000000?text=I%20am%20interested%20in%20property:%20${encodeURIComponent(prop.title)}" target="_blank" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-3 rounded-xl text-sm transition flex items-center justify-center">
                    <i class="fa-brands fa-whatsapp text-lg"></i>
                </a>
            </div>
        </div>
    `).join('');
}

// Load Initial Properties
document.addEventListener('DOMContentLoaded', () => {
    const props = JSON.parse(localStorage.getItem('up_properties'));
    renderProperties(props);
});

// Category Filter Buttons
function filterCategory(cat) {
    document.querySelectorAll('.cat-btn').forEach(btn => {
        btn.classList.remove('bg-slate-900', 'text-white');
        btn.classList.add('bg-slate-100', 'text-slate-600');
    });
    event.target.classList.remove('bg-slate-100', 'text-slate-600');
    event.target.classList.add('bg-slate-900', 'text-white');

    const props = JSON.parse(localStorage.getItem('up_properties'));
    if (cat === 'All') {
        renderProperties(props);
    } else {
        renderProperties(props.filter(p => p.type === cat));
    }
}

// Advanced Search Filtering
function applyFilters() {
    const type = document.getElementById('filterType').value;
    const location = document.getElementById('filterLocation').value.toLowerCase();
    const budget = Number(document.getElementById('filterBudget').value);

    let props = JSON.parse(localStorage.getItem('up_properties'));

    if (type) props = props.filter(p => p.type === type);
    if (location) props = props.filter(p => p.location.toLowerCase().includes(location));
    if (budget && budget > 0) props = props.filter(p => p.price <= budget);

    renderProperties(props);
    
    // Scroll smoothly to listings
    document.getElementById('properties').scrollIntoView({ behavior: 'smooth' });
}

// Property Details Modal
function openPropertyModal(id) {
    const props = JSON.parse(localStorage.getItem('up_properties'));
    const prop = props.find(p => p.id === id);
    if(!prop) return;

    const modalContent = document.getElementById('modalContent');
    modalContent.innerHTML = `
        <img src="${prop.image}" alt="${prop.title}" class="w-full h-72 object-cover">
        <div class="p-6 sm:p-8 space-y-4">
            <div class="flex items-center justify-between">
                <span class="bg-amber-500/10 text-amber-600 font-bold text-xs px-3 py-1 rounded-full uppercase">${prop.type}</span>
                <span class="font-black text-2xl text-slate-900">₹ ${Number(prop.price).toLocaleString('en-IN')}</span>
            </div>
            <h2 class="text-2xl font-black text-slate-900">${prop.title}</h2>
            <p class="text-slate-500 text-sm flex items-center gap-1"><i class="fa-solid fa-location-dot text-amber-500"></i> ${prop.location}</p>
            <p class="text-slate-600 leading-relaxed">${prop.description}</p>
            <div class="bg-slate-50 p-4 rounded-xl flex justify-between items-center text-sm font-semibold text-slate-700">
                <span>Plot / Area Size:</span>
                <span class="text-slate-900">${prop.size}</span>
            </div>
            <div class="flex gap-4 pt-4">
                <a href="https://wa.me/919881000000?text=Hello,%20I%20want%20to%20know%20more%20about%20${encodeURIComponent(prop.title)}" target="_blank" class="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-xl text-center transition flex items-center justify-center gap-2">
                    <i class="fa-brands fa-whatsapp text-lg"></i> Chat on WhatsApp
                </a>
                <a href="tel:+919881000000" class="bg-slate-900 hover:bg-slate-800 text-white font-bold px-6 py-3.5 rounded-xl text-center transition">
                    Call Now
                </a>
            </div>
        </div>
    `;

    document.getElementById('propertyModal').classList.remove('hidden');
    document.getElementById('propertyModal').classList.add('flex');
}

function closePropertyModal() {
    document.getElementById('propertyModal').classList.remove('flex');
    document.getElementById('propertyModal').classList.add('hidden');
}

// Lead Form Submission
function handleLeadSubmit(e) {
    e.preventDefault();
    const name = document.getElementById('leadName').value;
    const phone = document.getElementById('leadPhone').value;
    const interest = document.getElementById('leadInterest').value;
    const msg = document.getElementById('leadMsg').value;

    const leads = JSON.parse(localStorage.getItem('up_leads'));
    const newLead = { id: Date.now(), name, phone, interest, msg };
    leads.unshift(newLead);
    localStorage.setItem('up_leads', JSON.stringify(leads));

    alert('Thank you! Your inquiry has been submitted successfully. We will get back to you shortly.');
    document.getElementById('leadForm').reset();
}

// Admin Modal Handling
function openAdminLogin() {
    document.getElementById('adminModal').classList.remove('hidden');
    document.getElementById('adminModal').classList.add('flex');
}

function closeAdminLogin() {
    document.getElementById('adminModal').classList.remove('flex');
    document.getElementById('adminModal').classList.add('hidden');
}

function handleAdminLogin(e) {
    e.preventDefault();
    const pass = document.getElementById('adminPassInput').value;
    if (pass === 'admin123' || pass === 'noman') {
        closeAdminLogin();
        document.getElementById('adminPassInput').value = '';
        openAdminDashboard();
    } else {
        alert('Incorrect password! Try "admin123"');
    }
}

// Admin Dashboard Functions
function openAdminDashboard() {
    document.getElementById('adminDashboard').classList.remove('hidden');
    loadAdminData();
}

function closeAdminDashboard() {
    document.getElementById('adminDashboard').classList.add('hidden');
}

function loadAdminData() {
    const props = JSON.parse(localStorage.getItem('up_properties'));
    const leads = JSON.parse(localStorage.getItem('up_leads'));

    document.getElementById('statTotalProps').innerText = props.length;
    document.getElementById('statTotalLeads').innerText = leads.length;

    // Properties Table
    const propList = document.getElementById('adminPropertyList');
    propList.innerHTML = props.map(p => `
        <tr class="border-b text-sm">
            <td class="py-3 font-semibold text-slate-800 flex items-center gap-3">
                <img src="${p.image}" class="w-10 h-10 rounded-lg object-cover">
                ${p.title}
            </td>
            <td class="py-3 text-slate-600">${p.type}</td>
            <td class="py-3 text-slate-600">${p.location}</td>
            <td class="py-3 font-bold text-amber-600">₹ ${Number(p.price).toLocaleString('en-IN')}</td>
            <td class="py-3 text-right">
                <button onclick="deleteProperty(${p.id})" class="bg-red-100 hover:bg-red-200 text-red-600 px-3 py-1.5 rounded-lg text-xs font-bold transition">Delete</button>
            </td>
        </tr>
    `).join('');

    // Leads Table
    const leadsList = document.getElementById('adminLeadsList');
    leadsList.innerHTML = leads.map(l => `
        <tr class="border-b text-sm">
            <td class="py-3 font-semibold text-slate-800">${l.name}</td>
            <td class="py-3 text-slate-600"><a href="tel:${l.phone}" class="text-blue-600 hover:underline">${l.phone}</a></td>
            <td class="py-3"><span class="bg-amber-100 text-amber-800 px-2.5 py-1 rounded-md text-xs font-bold">${l.interest}</span></td>
            <td class="py-3 text-slate-600 max-w-xs truncate">${l.msg || 'N/A'}</td>
            <td class="py-3 text-right">
                <a href="https://wa.me/91${l.phone}?text=Hello%20${encodeURIComponent(l.name)},%20regarding%20your%20property%20inquiry%20with%20Unique%20Properties..." target="_blank" class="bg-emerald-100 hover:bg-emerald-200 text-emerald-700 px-3 py-1.5 rounded-lg text-xs font-bold transition inline-block">WhatsApp</a>
            </td>
        </tr>
    `).join('');
}

// Add New Property from Admin
function handleAddNewProperty(e) {
    e.preventDefault();
    const title = document.getElementById('newTitle').value;
    const type = document.getElementById('newType').value;
    const location = document.getElementById('newLocation').value;
    const price = Number(document.getElementById('newPrice').value);
    const size = document.getElementById('newSize').value;
    const image = document.getElementById('newImage').value;
    const description = document.getElementById('newDesc').value;

    const props = JSON.parse(localStorage.getItem('up_properties'));
    const newProp = { id: Date.now(), title, type, location, price, size, image, description };
    props.unshift(newProp);
    localStorage.setItem('up_properties', JSON.stringify(props));

    document.getElementById('addPropForm').reset();
    loadAdminData();
    renderProperties(props);
    alert('Property added successfully!');
}

// Delete Property
function deleteProperty(id) {
    if(confirm('Are you sure you want to delete this property listing?')) {
        let props = JSON.parse(localStorage.getItem('up_properties'));
        props = props.filter(p => p.id !== id);
        localStorage.setItem('up_properties', JSON.stringify(props));
        loadAdminData();
        renderProperties(props);
    }
}